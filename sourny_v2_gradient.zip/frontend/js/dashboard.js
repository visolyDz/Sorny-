// dashboard.js - demo interactions
const API = localStorage.getItem('SOURNY_API') || 'http://localhost:4000';
const token = localStorage.getItem('sourny_token');
const user = JSON.parse(localStorage.getItem('sourny_user')||'null');

if(!token){
  // allow preview mode
  document.getElementById('welcome').innerText = 'وضع المعاينة — قم بتسجيل الدخول لتجربة كاملة';
} else {
  document.getElementById('welcome').innerText = 'مرحبا، ' + (user?.name||'المستخدم');
}

// Simple in-memory orders for demo (or fetch from API if available)
let orders = JSON.parse(localStorage.getItem('sourny_demo_orders') || 'null') || [
  {id:1, client:'شركة أ', service:'تصميم', status:'مفتوح'},
  {id:2, client:'أحمد', service:'صيانة', status:'مغلق'}
];
function renderOrders(){
  const tbody = document.querySelector('#orders-table tbody');
  tbody.innerHTML = '';
  orders.forEach(o=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${o.id}</td><td>${o.client}</td><td>${o.service}</td><td>${o.status}</td>`;
    tbody.appendChild(tr);
  });
  document.getElementById('stat-count').innerText = 'الطلبات: ' + orders.length;
}
document.getElementById('add-order').addEventListener('click', ()=>{
  const client = prompt('اسم العميل');
  const service = prompt('الخدمة');
  if(!client||!service) return;
  const id = orders.length? orders[orders.length-1].id+1:1;
  orders.push({id, client, service, status:'مفتوح'});
  localStorage.setItem('sourny_demo_orders', JSON.stringify(orders));
  renderOrders();
});
document.getElementById('logout').addEventListener('click', ()=>{
  localStorage.removeItem('sourny_token');
  localStorage.removeItem('sourny_user');
  alert('تم تسجيل الخروج');
  location.href = '/frontend/login.html';
});
renderOrders();
