// auth.js - minimal demo to call backend API
const API = localStorage.getItem('SOURNY_API') || 'http://localhost:4000';

const loginForm = document.getElementById('login-form');
const regForm = document.getElementById('register-form');

document.getElementById('to-register').addEventListener('click', (e)=>{
  e.preventDefault();
  loginForm.style.display='none';
  regForm.style.display='block';
});
document.getElementById('to-login').addEventListener('click', (e)=>{
  e.preventDefault();
  loginForm.style.display='block';
  regForm.style.display='none';
});

document.getElementById('do-register').addEventListener('click', async ()=>{
  const name = document.getElementById('rname').value;
  const email = document.getElementById('remail').value;
  const pwd = document.getElementById('rpassword').value;
  if(!name||!email||!pwd) return alert('اكمل الحقول');
  const res = await fetch(API+'/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,password:pwd})});
  const j = await res.json();
  if(res.ok) {
    alert('تم إنشاء الحساب، يمكنك الآن تسجيل الدخول');
    location.reload();
  } else alert(j.message || 'خطأ');
});

loginForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const email = document.getElementById('email').value;
  const pwd = document.getElementById('password').value;
  const res = await fetch(API+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password:pwd})});
  const j = await res.json();
  if(res.ok){
    localStorage.setItem('sourny_token', j.token);
    localStorage.setItem('sourny_user', JSON.stringify(j.user));
    alert('تم تسجيل الدخول');
    location.href = '/frontend/dashboard.html';
  } else alert(j.message || 'فشل الدخول');
});
