// backend/server.js - Express + JWT demo (in-memory)
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const SECRET = process.env.JWT_SECRET || 'sourny_dev_secret';
let users = []; // in-memory
let orders = [
  {id:1, client:'شركة أ', service:'تصميم موقع', status:'مفتوح'}
];

function genToken(user){ return jwt.sign({id:user.id,email:user.email}, SECRET, {expiresIn:'7d'}); }
function authMiddleware(req,res,next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({message:'Missing token'});
  const token = h.replace('Bearer ','');
  try{
    const decoded = jwt.verify(token, SECRET);
    req.user = decoded;
    next();
  }catch(e){ return res.status(401).json({message:'Invalid token'}); }
}

// Register
app.post('/api/register', (req,res)=>{
  const {name,email,password} = req.body;
  if(!email||!password||!name) return res.status(400).json({message:'Incomplete'});
  if(users.find(u=>u.email===email)) return res.status(400).json({message:'Email exists'});
  const user = {id: users.length+1, name, email, password};
  users.push(user);
  res.status(201).json({message:'Created', user:{id:user.id,name:user.name,email:user.email}});
});

// Login
app.post('/api/login', (req,res)=>{
  const {email,password} = req.body;
  const user = users.find(u=>u.email===email && u.password===password);
  if(!user) return res.status(401).json({message:'Invalid credentials'});
  const token = genToken(user);
  res.json({token, user:{id:user.id,name:user.name,email:user.email}});
});

// Protected orders
app.get('/api/orders', authMiddleware, (req,res)=>{
  res.json(orders);
});
app.post('/api/orders', authMiddleware, (req,res)=>{
  const o = req.body;
  o.id = orders.length? orders[orders.length-1].id+1:1;
  orders.push(o);
  res.status(201).json(o);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Sourny backend running on', PORT));
